import React, { createRef } from 'react';
import '../payment.css';
import OrderSummary from './OrderSummary.jsx';
import 'bootstrap/js/dist/collapse';

class Payment extends React.Component {
    constructor(props) {
        super(props);
        this.fullNameRef = createRef();
        this.selectDelivery = createRef();
        this.state = {
            deliveryAmount: 0,
            MessageFullName: '',
            invalidMessages: {  required: "This field is required"
                                                             
                             }
        }
    }

    calculateDelivery = () => {
        let totalAmount = this.props.getSubTotalAmount();
        if (totalAmount < 50){
            return 50;
        }
        else if (totalAmount >= 50 && totalAmount < 125){
            return 75;
        }
        else if (totalAmount >= 125 && totalAmount < 200){
            return 100;
        }
        else{
            return 0;
        }
    }

    onChangeDelivery = () => {
        console.log(this.state)
        switch (this.selectDelivery.current.value){
            case 'Self-pickup':
                this.setState({deliveryAmount: 0}, () => {console.log(this.state.deliveryAmount)});
                break;
            case 'Postal-service':
                this.setState({deliveryAmount: 10}, () => {console.log(this.state.deliveryAmount)});
                break;
            case 'Registered-mail':
                this.setState({deliveryAmount: 30}, () => {console.log(this.state.deliveryAmount)});
                break;
            case 'emissary':
                let deliveryAmount = this.calculateDelivery();
                this.setState({deliveryAmount}, () => {console.log(this.state.deliveryAmount)});
                break;
        }
    }

    getTotalAmountAfterDelivery = () => {
        return this.props.getSubTotalAmount() * (1 +this.props.tax) + this.state.deliveryAmount;
    }

    submitCostumerDetails = () => {
        let MessageFullName = '';
        // console.log(this.fullNameRef.current.validity.valueMissing);
        if(this.fullNameRef.current.validity.valueMissing){
            MessageFullName = this.state.invalidMessages.required;
            this.setState({MessageFullName}, () => console.log(this.state.MessageFullName));
        }
    }

    render() {
        return (
            <div className="container">
                <h3 className="text-center mb-4">Check-Out</h3>
                <div className="row">
                    <div className="col-12 col-md-8 paymentForm">
                       
                            <div className="col-12 col-md-10 border-bottom" style={{borderColor: '#d9d9d9'}}>
                                <button className="btn btn-light btn-block text-left" type="button" data-toggle="collapse" data-target="#costumerDetails" aria-expanded="false" aria-controls="collapseExample">
                                    Costumer details
                                </button>
                                <div className="collapse mb-2" id="costumerDetails">
                                    <form>
                                        <div className="form-group mt-2 payment-form">
                                            <label htmlFor="fullName">Full name: </label>
                                            <input type="text" className="form-control" ref={this.fullNameRef} style={{display: "inline-block !important"}} required></input>
                                            <div class="invalid-feedback">
                                                {this.state.MessageFullName}
                                            </div>

                                            <label htmlFor="phone">Phone: </label>
                                            <input type="tel" className="form-control" id="phone" required></input>
                                            
                                            <label htmlFor="email">Email: </label>
                                            <input type="tel" className="form-control" id="email" required></input>
                                            
                                            <div className="form-check mt-2">
                                                <input type="checkbox" className="form-check-input" id="ReceiveMarketingInfo" required></input>
                                                <label className="form-check-label mb-2" htmlFor="ReceiveMarketingInfo">I would like to receive information about products and promotions on the site</label>
                                            </div>
                                            
                                            <button type="submit" className="btn btn-primary btn-sm" onClick={this.submitCostumerDetails}>Next</button>
                                        </div>
                                    </form> 
                                </div>
                            </div> 

                            <div className="col-12 col-md-10 mt-4 border-bottom" style={{borderColor: '#d9d9d9'}}>
                                <button className="btn btn-light btn-block text-left" type="button" data-toggle="collapse" data-target="#RecipientDetails" aria-expanded="false" aria-controls="collapseExample">
                                    Recipient of shipment details
                                </button>
                                <div className="collapse mb-2" id="RecipientDetails">
                                    <form>
                                        <div className="form-group mt-2">
                                            <div className="form row">
                                                <div className="col-6">
                                                    <label htmlFor="firstName">First name:</label>
                                                    <input type="text" className="form-control" id="firstName" required></input>
                                                </div>
                                                <div className="col-6">
                                                    <label htmlFor="lastName">Last name:</label>
                                                    <input type="text" className="form-control" id="lastName" required></input>
                                                </div>
                                            </div>
                                            <div className="form row">
                                                <div className="col-12 col-md-6">
                                                    <label htmlFor="street">Street:</label>
                                                    <input type="text" className="form-control" id="street" required></input>
                                                </div>
                                                <div className="col-12 col-md-3">
                                                    <label htmlFor="homeNumber">Home number:</label>
                                                    <input type="number" className="form-control" id="homeNumber" required></input>
                                                </div>
                                                <div className="col-12 col-md-3">
                                                    <label htmlFor="apartmentNumber">Apartment number:</label>
                                                    <input type="number" className="form-control" id="apartmentNumber" required></input>
                                                </div>
                                            </div>
                                            
                                            <label htmlFor="city">City:</label>
                                            <input type="text" className="form-control mb-4" id="city" required></input>
                                        
                                            <button type="submit" className="btn btn-primary btn-sm">Next</button> 
                                        </div>  
                                    </form> 
                                </div>
                            </div>

                            <div className="col-12 col-md-10 mt-4">
                                <div className="form-group">
                                    <label htmlFor="deliverySelect">Delivery:</label>
                                    <select className="form-control" ref={this.selectDelivery} onChange={this.onChangeDelivery}>
                                        <option value="Self-pickup">Self-pickup: $0</option>
                                        <option value="Postal-service">Postal service: $10</option>
                                        <option value="Registered-mail">Registered mail: $30</option>
                                        <option value="emissary">emissary: ${this.calculateDelivery().toLocaleString()} - Free over $200</option>
                                    </select>
                                </div>
                            </div>
                        
                            <div className="col-12 col-md-10 mt-2">
                                <button type="submit" className="btn btn-primary">Payment</button> 
                            </div>
                                              
                    </div>
                    <div className="col-12 col-md-4">
                        <OrderSummary
                            cartProducts={this.props.cartProducts} 
                            getSubTotalAmount={this.props.getSubTotalAmount} 
                            tax={this.props.tax} >
                        </OrderSummary>
                        <p>Delivery: ${this.state.deliveryAmount}</p>
                        <p><b>Total after delivery: <span className="text-success">${this.getTotalAmountAfterDelivery().toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</span></b></p>
                    </div>
                </div>
            </div>
        )
    }
}

export default Payment;

{/* <button className="btn btn-light btn-block text-left" type="button" data-toggle="collapse" data-target="#deliveryDetails" aria-expanded="false" aria-controls="collapseExample">
Delivery
</button>
<div className="collapse" id="deliveryDetails"> */}
{/* <div className="form-check">
<input className="form-check-input" type="radio" name="deliverySelect" value="Self-pickup" checked></input>
<label className="form-check-label" htmlFor="Self-pickup">
    Self-pickup: $0
</label>
</div>
<div className="form-check">
<input className="form-check-input" type="radio" name="deliverySelect" value="Postal-service"></input>
<label className="form-check-label" htmlFor="Postal-service">
    Postal service: $10
</label>
</div>
<div className="form-check">
<input className="form-check-input" type="radio" name="deliverySelect" value="Registered-mail"></input>
<label className="form-check-label" htmlFor="Registered-mail">
    Registered mail: $30
</label>
</div>
<div className="form-check">
<input className="form-check-input" type="radio" name="deliverySelect" value="emissary"></input>
<label className="form-check-label" htmlFor="emissary">
    emissary: ${this.calculateDelivery().toLocaleString()} - Free over $200
</label>
</div> */}
 {/* </div> */}