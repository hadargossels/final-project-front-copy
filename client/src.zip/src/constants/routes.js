export const SIGN_UP = '/register';
export const SIGN_IN = '/register';
export const HOME = '/';