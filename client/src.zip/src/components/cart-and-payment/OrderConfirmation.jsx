import React, { Component } from 'react';

class OrderConfirmation extends Component {
    render() {
        return (
            <div className="container">
               <h1>Order Confirmation</h1>
               <h3>Order number: </h3>
            </div>
        );
    }
}

export default OrderConfirmation;