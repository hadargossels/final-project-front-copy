import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import {firebasedb} from '../../firebase';


export default function OrderSummary(props) {

    const cuponInputRef = useRef();
    const cuponDiscountRef = useRef();
    const totalAmountRef = useRef();
    const amountAfterCupon = useRef();
    const [coupons, setCoupons] = useState({ pending: false, value: undefined })
    const [myCoupon, setMyCoupon] = useState({ pending: false, value: undefined })


    useEffect(() => {
        console.log("effect1")
        const fetchData = async () => {
            setCoupons({ pending: true, value: undefined });
            const snapshot = await firebasedb.ref('coupons').get()
            setCoupons({ pending: true, value: snapshot.val() });
        };
        
        fetchData();
    },[])   

    useEffect(() => {
        console.log("effect2")
        setMyCoupon({ pending: true, value: undefined });
        const coupon = JSON.parse(localStorage.getItem('myCoupon'));
        if (coupon && myCoupon && coupon.code !== myCoupon.value.code)
            setMyCoupon({ pending: true, value: coupon });
    }, [myCoupon])


    const getTotalAmount = () => {
        return props.getSubTotalAmount() * (1 +props.tax);
    }

    const onActivateCoupon = (e) => {
        e.preventDefault();
        activateCoupon();
    }

    const activateCoupon = () => {
        
        if (cuponInputRef.current.value) {   
            let cuponConfirmed = false
            Object.keys(coupons.value).forEach(element => {
                if (element === cuponInputRef.current.value){
                    cuponConfirmed = true;
                    const coupon = {code: element, discount: coupons.value[element]}
                    setMyCoupon({ pending: true, value: coupon });
                    localStorage.setItem('myCoupon', JSON.stringify(coupon));
                    totalAmountRef.current.style.textDecorationLine = "line-through";
                    // cuponDiscountRef.current.style.display = "block";
                    // amountAfterCupon.current.style.display = "block";
                }
            });
            if (!cuponConfirmed){
                alert("Coupon code is invalid")
            }
        }
    }

        
    return (
    <>
    {console.log(myCoupon)}
        <h4 className="border-bottom pb-2">Order Summary</h4>
        <p>Subtotal: ${(props.getSubTotalAmount()).toLocaleString()}</p>
        <p>Taxes: ${((props.getSubTotalAmount() * props.tax).toFixed(2)).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</p>
        <form>
            <div className="form-group">
                <label htmlFor="cupon">Cupon-code:</label>
                <input type="text" className="form-control d-inline" id="cuponInput" ref={cuponInputRef} defaultValue={myCoupon ? myCoupon.value.code : ''}></input>
                <button type="submit" className="btn btn-outline-primary btn-sm d-inline" onClick={onActivateCoupon}>Activate coupon</button>
            </div>
        </form>

        {myCoupon?
            <div className="text-success" ref={cuponDiscountRef}>
                {myCoupon.value.discount * 100}% discount
            </div>
        : null
        }
        <p className="mt-1">
            <b>Total:</b> <span className="text-success" ref={totalAmountRef}>${(getTotalAmount()).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</span>
        </p>
        {myCoupon ?
            <p className="text-success" ref={amountAfterCupon}>
                ${(getTotalAmount() * (1 - myCoupon.value.discount)).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
            </p>
        : null
        }
                    
    </>
    )

}

